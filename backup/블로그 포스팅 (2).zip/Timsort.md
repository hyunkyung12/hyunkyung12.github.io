# Timsort 

파이썬으로 소팅 알고리즘 문제를 풀다보니, 파이썬 내장함수인 ``sorted`` 를 사용하면 간단했습니다.

그러면 이 ``sorted`` 함수는 어떤 소팅 알고리즘으로 구성된 걸까요?



https://hackernoon.com/timsort-the-fastest-sorting-algorithm-youve-never-heard-of-36b28417f399